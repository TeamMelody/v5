-- MySQL dump 10.13  Distrib 5.1.69, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: u733886938_mel
-- ------------------------------------------------------
-- Server version	5.1.69
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Course`
--

DROP TABLE IF EXISTS `Course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Course` (
  `CourseCode` int(11) NOT NULL AUTO_INCREMENT,
  `SchoolID` int(11) NOT NULL,
  `Level` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `CourseTitle` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `URL` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `CourseCodeTitle` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CourseCode`),
  KEY `SchoolID` (`SchoolID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Course`
--

LOCK TABLES `Course` WRITE;
/*!40000 ALTER TABLE `Course` DISABLE KEYS */;
INSERT INTO `Course` VALUES (3,2,'Undergraduate','BSc(Hons) Music Technology and Audio Systems','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/music-technology-and-audio-systems-bsc-hons/','H6W3'),(2,2,'Undergraduate','BA(Hons) Music Technology','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/music-technology-ba-hons/','HW63'),(1,1,'Undergraduate','BMus (Hons) Music','http://www.hud.ac.uk/courses/full-time/undergraduate/music-bmus-hons','W300'),(4,2,'Undergraduate','BA(Hons) Music Technology and Popular Music','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/music-technology-and-popular-music-ba-hons/','JWX3'),(5,1,'Undergraduate','BMus (Hons) Music Performance','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/music-performance-bmus-hons/','W3W3'),(6,1,'Undergraduate','BMus (Hons) Popular Music','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/popular-music-bmus-hons/','W3W8'),(7,2,'Undergraduate','BA (Hons) Popular Music Production','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/popular-music-production-ba-hons/','WJ39'),(8,2,'Undergraduate','BSc (Hons) Popular Music Production','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/popular-music-production-bsc-hons/','JW93'),(9,2,'Undergraduate','BMus (Hons) Creative Music Technology','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/creative-music-technology-bmus-hons/','J931'),(10,1,'Undergraduate','BA (Hons) Music and Sound for Image','http://www.hud.ac.uk/courses/2015-16/full-time/undergraduate/music-and-sound-for-image-ba-hons/','WJ36');
/*!40000 ALTER TABLE `Course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CourseKeySkills`
--

DROP TABLE IF EXISTS `CourseKeySkills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CourseKeySkills` (
  `CourseCode` int(11) NOT NULL,
  `KSID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Weight` int(11) NOT NULL,
  PRIMARY KEY (`CourseCode`,`KSID`),
  KEY `KSID` (`KSID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CourseKeySkills`
--

LOCK TABLES `CourseKeySkills` WRITE;
/*!40000 ALTER TABLE `CourseKeySkills` DISABLE KEYS */;
INSERT INTO `CourseKeySkills` VALUES (5,'Solo Performance',3),(5,'Composing',1),(5,'Music Research',2),(5,'Music Theory',3),(5,'Songwriting',1),(5,'Group Performance',3),(5,'Film',1),(1,'Solo Performance',2),(1,'Composing',3),(1,'Music Research',3),(1,'Music Theory',3),(1,'Songwriting',1),(1,'Group Performance',3),(1,'Film',1),(6,'Solo Performance',2),(6,'Composing',2),(6,'Music Research',2),(6,'Music Theory',3),(6,'Songwriting',3),(6,'Group Performance',3),(6,'Film',2),(4,'Software Development',1),(4,'Solo Performance',2),(4,'Composing',2),(4,'Music Research',2),(4,'Music Theory',2),(4,'Songwriting',3),(4,'Group Performance',3),(4,'Recording',2),(4,'Film',2),(9,'Software Development',2),(9,'Solo Performance',2),(9,'Composing',3),(9,'Music Research',2),(9,'Music Theory',3),(9,'Songwriting',1),(9,'Group Performance',3),(9,'Recording',2),(9,'Film',2),(10,'Software Development',1),(10,'Solo Performance',1),(10,'Composing',3),(10,'Music Research',1),(10,'Music Theory',3),(10,'Songwriting',1),(10,'Group Performance',2),(10,'Recording',2),(10,'Film',3),(2,'Software Development',3),(2,'Composing',2),(2,'Music Research',1),(2,'Group Performance',1),(2,'Recording',2),(2,'Film',2),(3,'Software Development',3),(3,'Composing',1),(3,'Music Research',1),(3,'Recording',3),(3,'Film',1),(8,'Software Development',3),(8,'Music Research',1),(8,'Recording',3),(8,'Film',1),(7,'Software Development',2),(7,'Composing',1),(7,'Music Research',1),(7,'Songwriting',1),(7,'Group Performance',2),(7,'Recording',3),(7,'Film',1);
/*!40000 ALTER TABLE `CourseKeySkills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CourseModule`
--

DROP TABLE IF EXISTS `CourseModule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CourseModule` (
  `CourseCode` int(11) NOT NULL,
  `ModuleCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`CourseCode`,`ModuleCode`),
  KEY `ModuleCode` (`ModuleCode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CourseModule`
--

LOCK TABLES `CourseModule` WRITE;
/*!40000 ALTER TABLE `CourseModule` DISABLE KEYS */;
INSERT INTO `CourseModule` VALUES (1,'AFM1101'),(1,'AFM1110'),(1,'AFM1205'),(1,'AFM1208'),(1,'AFM1211'),(1,'AFM1213'),(1,'AFM1303'),(1,'AFM1406'),(1,'AHM1415'),(1,'AHM3108'),(1,'AHM3109'),(1,'AHM3208'),(1,'AHM3310'),(1,'AHM3311'),(1,'AHM3313'),(1,'AHM3403'),(1,'AHM3409'),(1,'AHM3412'),(1,'AHM3413'),(1,'AHM3416'),(1,'AHM3417'),(1,'AHM3506'),(1,'AHM3511'),(1,'AHM3518'),(1,'AIM2106'),(1,'AIM2108'),(1,'AIM2109'),(1,'AIM2205'),(1,'AIM2302'),(1,'AIM2307'),(1,'AIM2310'),(1,'AIM2311'),(1,'AIM2312'),(1,'AIM2408'),(1,'AIM2411'),(1,'AIM2412'),(1,'AIM2416'),(1,'AIM2417'),(1,'AIM2506'),(2,'AFM1205'),(2,'AFM1211'),(2,'AFM1404'),(2,'AHM3109'),(2,'AHM3208'),(2,'AHM3209'),(2,'AHM3311'),(2,'AHM3409'),(2,'AHM3412'),(2,'AHM3505'),(2,'AHM3506'),(2,'AIM1207'),(2,'AIM2205'),(2,'AIM2207'),(2,'AIM2210'),(2,'AIM2310'),(2,'AIM2408'),(2,'AIM2412'),(2,'AIM2505'),(2,'CFT2130'),(2,'CIT2310'),(2,'NFE2140'),(2,'NFE2172 '),(2,'NFE2173'),(2,'NHE2425'),(2,'NHE2431'),(2,'NHE2475'),(2,'NIE2236'),(2,'NIE2237'),(2,'testcode'),(3,'AFM1504'),(3,'CFT2130'),(3,'CIT2310'),(3,'NFE2140'),(3,'NFE2160'),(3,'NFE2172 '),(3,'NFE2173'),(3,'NHE2425'),(3,'NHE2429'),(3,'NHE2431'),(3,'NHE2440 '),(3,'NHE2475'),(3,'NHE2490'),(3,'NHE2491'),(3,'NIE2236'),(3,'NIE2237'),(3,'NIE2274'),(3,'NIE2280'),(3,'NIE2285'),(3,'NIE2286'),(3,'testcode'),(4,'AFM1101'),(4,'AFM1205'),(4,'AFM1209'),(4,'AFM1210'),(4,'AFM1211'),(4,'AFM1212'),(4,'AFM1404'),(4,'AHM1415'),(4,'AHM3109'),(4,'AHM3208'),(4,'AHM3209'),(4,'AHM3409'),(4,'AHM3410'),(4,'AHM3412'),(4,'AHM3505'),(4,'AIM1207'),(4,'AIM2105'),(4,'AIM2106'),(4,'AIM2108'),(4,'AIM2205'),(4,'AIM2207'),(4,'AIM2208'),(4,'AIM2210'),(4,'AIM2302'),(4,'AIM2310'),(4,'AIM2408'),(4,'AIM2411'),(4,'AIM2412'),(4,'AIM2416'),(4,'AIM2505'),(4,'CFT2130'),(4,'CIT2310'),(4,'NFE2173'),(4,'NIE2236'),(5,'AFM1101'),(5,'AFM1110'),(5,'AFM1205'),(5,'AFM1208'),(5,'AFM1211'),(5,'AFM1213'),(5,'AFM1303'),(5,'AFM1304'),(5,'AFM1406'),(5,'AHM3109'),(5,'AHM3310'),(5,'AHM3311'),(5,'AHM3313'),(5,'AHM3403'),(5,'AHM3409'),(5,'AHM3412'),(5,'AHM3413'),(5,'AHM3416'),(5,'AHM3417'),(5,'AHM3506'),(5,'AHM3518'),(5,'AIM2108'),(5,'AIM2109'),(5,'AIM2302'),(5,'AIM2307'),(5,'AIM2310'),(5,'AIM2311'),(5,'AIM2312'),(5,'AIM2408'),(5,'AIM2411'),(5,'AIM2412'),(5,'AIM2416'),(5,'AIM2417'),(5,'AIM2506'),(6,'AFM1101'),(6,'AFM1205'),(6,'AFM1208'),(6,'AFM1211'),(6,'AFM1213'),(6,'AFM1303'),(6,'AFM1304'),(6,'AFM1406'),(6,'AHM1415'),(6,'AHM3109'),(6,'AHM3208'),(6,'AHM3310'),(6,'AHM3311'),(6,'AHM3403'),(6,'AHM3409'),(6,'AHM3412'),(6,'AHM3416'),(6,'AHM3506'),(6,'AHM3518'),(6,'AIM2110'),(6,'AIM2205'),(6,'AIM2302'),(6,'AIM2310'),(6,'AIM2312'),(6,'AIM2408'),(6,'AIM2411'),(6,'AIM2412'),(6,'AIM2416'),(6,'AIM2505'),(7,'AFM1404'),(7,'AFM1504'),(7,'AHM3409'),(7,'AIM2408'),(7,'CFT2130'),(7,'CIT2310'),(7,'NFE2160'),(7,'NFE2172 '),(7,'NFE2173'),(7,'NHE2425'),(7,'NHE2429'),(7,'NHE2440 '),(7,'NHE2490'),(7,'NHE2491'),(7,'NIE2236'),(7,'NIE2280'),(7,'NIE2285'),(7,'NIE2286'),(8,'AFM1504'),(8,'CFT2130'),(8,'CIT2310'),(8,'NFE2140'),(8,'NFE2160'),(8,'NFE2172 '),(8,'NFE2173'),(8,'NHE2425'),(8,'NHE2429'),(8,'NHE2440 '),(8,'NHE2490'),(8,'NHE2491'),(8,'NIE2236'),(8,'NIE2280'),(8,'NIE2285'),(8,'NIE2286'),(9,'AFM1101'),(9,'AFM1205'),(9,'AFM1211'),(9,'AFM1213'),(9,'AFM1404'),(9,'AFM1406'),(9,'AFM1507'),(9,'AFM1906'),(9,'AHM1415'),(9,'AHM3105'),(9,'AHM3108'),(9,'AHM3109'),(9,'AHM3208'),(9,'AHM3209'),(9,'AHM3309'),(9,'AHM3310'),(9,'AHM3311'),(9,'AHM3403'),(9,'AHM3409'),(9,'AHM3413'),(9,'AHM3505'),(9,'AHM3506'),(9,'AIM1207'),(9,'AIM2106'),(9,'AIM2108'),(9,'AIM2109'),(9,'AIM2205'),(9,'AIM2207'),(9,'AIM2208'),(9,'AIM2209'),(9,'AIM2210'),(9,'AIM2307'),(9,'AIM2308'),(9,'AIM2310'),(9,'AIM2408'),(9,'AIM2409'),(9,'AIM2411'),(9,'AIM2412'),(9,'AIM2505'),(9,'AIM2506'),(9,'NFE2173'),(9,'NIE2236'),(10,'AFC1403'),(10,'AFM1101'),(10,'AFM1213'),(10,'AFM1404'),(10,'AFM1406'),(10,'AFM1507'),(10,'AHM3105'),(10,'AHM3109'),(10,'AHM3208'),(10,'AHM3209'),(10,'AHM3409'),(10,'AHM3412'),(10,'AHM3505'),(10,'AHM3506'),(10,'AIM1207'),(10,'AIM2108'),(10,'AIM2205'),(10,'AIM2207'),(10,'AIM2208'),(10,'AIM2209'),(10,'AIM2408'),(10,'AIM2412'),(10,'AIM2505'),(10,'CFT2130'),(10,'CIT2310'),(10,'NFE2173'),(10,'NIE2236');
/*!40000 ALTER TABLE `CourseModule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `KeySkills`
--

DROP TABLE IF EXISTS `KeySkills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `KeySkills` (
  `KSID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`KSID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `KeySkills`
--

LOCK TABLES `KeySkills` WRITE;
/*!40000 ALTER TABLE `KeySkills` DISABLE KEYS */;
INSERT INTO `KeySkills` VALUES ('Software Development','Learn computer programming, documenting, testing and bug fixing to create music related technologies'),('Solo Performance','Individual tuition on your instrument, leading to a solo recital, classical or pop instruments or voice'),('Composing','Research, transcribe and create music using computer software'),('Music Research','Research the music of different decades and discuss the issues relating to notation, performance and compositional practice'),('Music Theory','Learn theoretical music skills'),('Songwriting','Advanced songwriting classes, including workshops. Compose your own songs '),('Group Performance','Perform covers and original material in a band of your choice'),('Recording','Learn to use notation software, record sound and write music using computer software'),('Film','Research and create music for film and study advanced scoring techniques'),('sedfdsg','asdfasdfsdf');
/*!40000 ALTER TABLE `KeySkills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Module`
--

DROP TABLE IF EXISTS `Module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Module` (
  `ModuleCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `ModuleTitle` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Description` text COLLATE utf8_unicode_ci NOT NULL,
  `Year` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`ModuleCode`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Module`
--

LOCK TABLES `Module` WRITE;
/*!40000 ALTER TABLE `Module` DISABLE KEYS */;
INSERT INTO `Module` VALUES ('AHM3105','Advanced Composition','This module offers an essential introduction to the fundamentals of composition by exploring the various musical parameters of melody, harmony, rhythm, timbre and texture through a series of preliminary exercises given in seminars and group tutorials.','Final Year'),('NHE2475','Audio Electronics','Analysis, design, build and test of audio circuits & systems with technical report writing and presentation. Using practical examples, data sheets and application of electronic theory audio transistor amplifiers, IC audio amplifiers, valve amplifier design, audio filters, mixing consoles, guitar and studio processors and audio equalisation networks will be explored.','Year Two'),('NIE2237','Audio Plug-Ins And Web Audio','This module provides an overview of advanced programming techniques. Programming experience will be gained in C/C++ and HTML/Javascript/Web Audio/Canvas, resulting in the production of audio/MIDI processing routines, audio plug-ins and graphical user interfaces.','Year Two'),('NFE2172 ','Audio Technology 1','The module will introduce you to audio principles such as signals, acoustics, hearing, basic electronics and digital audio.','Year One'),('AFM1212','Audiovision in Context','Your approach to studying music and sound for image will depend on having a good understanding of the range and context of the ways this has been achieved both historically and in the present time. Audiovision in context is a broad ranging study of how sonic and visual work together to inspire not only film and television but a range of other practices from art to videogames. You’ll engage with the analysis of audiovisual practice and develop key theoretical concepts which will support your academic studies.','Year One'),('NHE2490','Business And The Music Industry','In a continually re-shaping industry, this module will provide you with a greater awareness of how music is now being created, consumed and, with a view to future developments, exploited as a commodity in the larger context of the entertainment world','Final Year'),('AIM2208','Composing Music for Film A','You will develop practical composition skills for writing film scores. Informed by your developing knowledge of film semiology and musical codes, you will learn about ‘spotting’, how to calculate timings and prepare for composition, while applying your ability to ‘read’ media and compose original music for it. The module discusses musical functions in particular styles, highlighting techniques for working with themes, managing transitions and how to show diversity of skill when building audiovisual relationships in music.','Year Two'),('AFM1101','Composition 1','Create your own music','Year One'),('AFM1210','Composition of Popular Music','You will create your own songs by studying different genres and techniques to enable you to find your own, distinctive compositional voice, helping you to stand out in the crowd as a songwriter. Skills you will develop include song writing, arranging, preparing lead sheets and recording demos. The assessment consists of small projects exploring specific techniques leading towards two complete compositions for a full band.','Year One'),('NFE2160','Computer Composition & Sound Design 1 (Ccsd)','Computer composition and sound design.  Develop an independence of thought and an ability to use a range of skills and techniques in a range of small creative projects. Study techniques and the creative potential of combining a variety of approaches to electronic music in a number of different musical styles.','Year Two'),('AFM1205','Computer Composition 1','Write your own music using computer software, including options to work with film','Year One'),('AIM2205','Computer Composition 2','Write your own music using computer software, including options to work with film','Year Two'),('AHM3208','Computer Composition 3','Write your own music using computer software, including options to work with film','Final Year'),('NIE2280','Computer Composition And Sound Design 2 (Ccsd2)','Study techniques and the creative potential of combining a variety of approaches to electronic music in a number of different musical styles.','Year One'),('AFM1507','Counterpoint Harmony and Analysis','You will study counterpoint in two parts in the style of Palestrina and four-part harmony in the style of Bach. The final part of the module looks at approaches to the analysis of music from the late-baroque period to the early-romantic period.','Year One'),('NHE2491','Creative Programming With Midi And Digital Audio','Advanced understanding in the use of computers for musical programming using software and the creative application of these techniques.','Final Year'),('NHE2431','Digital Audio Signal Processing','Manipulation of audio signals and the technology of digital audio systems','Final Year'),('AIM2210','Electronic Music in Context','The module will examine a number of contexts in which electronic technologies play a significant role in the production of music. The implications of aesthetics and perception in new media and performance situations will be discussed along with the similarities/divergences between a number of trends and in current creative practice.','Year Two'),('AIM2310','Experimental Music 1','Explore contemporary experimental music through research, composition and performance','Year Two'),('AHM3311','Experimental Music 2','Explore contemporary experimental music through research, composition and performance','Final Year'),('AFM1211','Grooves, Glitches And Crackles','Research the history of popular music','Year One'),('AIM2307','Historical Performance','Research the evidence for how music of the past was performed','Year Two'),('NHE2440 ','Individual Project (Music Technology)','Based on any of the subject areas of your previous modules on the course, you will be provided with an opportunity to  undertake a substantial project from a suitable objective to a satisfactory conclusion.','Final Year'),('AIM1207','Interactive Sound Design 1','This is a creative module using the software Max, a graphical programming language used to develop digital instruments. You will be introduced to the software and learn its basic programming techniques, gaining experience working creatively with these techniques. Though no previous programming experience is required.','Year One'),('AIM2207','Interactive Sound Design 2','This module follows on from Interactive Sound Design 1 in developing skills for working with sound interactively using the graphical programming language Max. The module deals with more advanced programming techniques including the use of frequency domain processing and granulation, as well as exploring more sophisticated creative uses.','Year Two'),('AIM2106','Intermediate Composition','Individual tuition on a composition portfolio','Year Two'),('AFM1303','Introduction To Analysis','Learning how music works, Music notation and theory skills','Year One'),('CFT2130','Introduction to Digital Media and the Internet','Serving as an introductory module to the web, you will be taught how to design websites and their individual pages, as well as creating your own branding/graphics and, of course, building it to make it live for the world to see. You will also learn about modern methods of marketing on the web and you will be creating your own content managed blog. You will also be making your own YouTube Channel and videos as well as practicing the art of social networking to get people around the world seeing and listening your content. ','Year One'),('AFM1304','Introduction To Music Research','Learn to be an effective researcher in music','Year One'),('AFM1504','Introduction to Music Theory','This module will provide a grounding in music theory applicable to the field of music technology and sound recording.','Year One'),('NIE2285','Live Music Production','This module introduces you to live sound engineering. It covers the practical aspects involved in live music production  and provides practical experience of working in a team to produce a live performance in a venue.','Year Two'),('NIE2274','Microcontrollers And Acoustics','A module composed in two disticnts part. 1:Understanding of the hardware and software aspects of microcontroller interfacing. 2: The theory and analysis of acoustic signals and simulation of acoustic behaviour','Year Two'),('AHM3309','Music and Gender','This module explores the relationship between music and gender in various historical contexts. It encourages you to question the relationship between creativity and gender in diverse areas of musical activity, from composition and scholarship to performance itself.','Final Year'),('AIM2505','Music and the Moving Image','This module explores the relationship between the soundtrack and moving image. You will develop an understanding of the historical context of the soundtrack from silent film to the present day. Using analysis tools, the module encourages you to develop a detailed understanding of the function that music and sound has in film. While there is a strong focus on film, the module also looks at games music, TV idents, animation and music video.','Year Two'),('AFM1906','Music History and Culture 1','This module examines music from the Medieval through to the Classical periods, adopting a diverse range of approaches to understanding and studying music. Specific key works are discussed and placed within wider social, political, artistic and musical concerns so that you gain a greater understanding of how music relates to and is borne out of geographic and historical contexts.','Year One'),('AIM2308','Music History and Culture 2','You will study a variety of music from the early 19th Century up to the middle of the 20th, focusing on a series of case studies which cover some of the most significant composers and developments.','Year Two'),('AHM3109','Music In The 21St Century','Research the music of recent decades and discuss the issues relating to notation, performance, and compositional practice','Final Year'),('AIM2311','Music In Vienna 1770?1830','Research Austria?s history of classical and romantic music','Year Two'),('AHM3518','Music Major Project','A substantial and advanced piece of original research or creative work, individually or in collaboration, supported by individual tuition','Final Year'),('AHM3505','Music Media and Markets','This module looks at different aspects of musical practice in contemporary culture. The selected case studies will introduce some of the different ways in which music is produced, distributed and represented both globally and within contemporary British society.','Final Year'),('AHM3313','Music On Stage: Opera And Musical Theatre From Orfeo To Matilda 2','Research the history of dramatic music','Final Year'),('AIM2108','Orchestration 1','Learn to write effectively for orchestra, using historical models','Year Two'),('AHM3108','Orchestration 2','Learn to write effectively for orchestra, using historical models','Final Year'),('AFM1406','Performance Skills 1','Improvisation, singing, aural skills, aural dictation','Year One'),('AIM2411','Performance Skills 2 (Major)','Improvisation, singing, aural skills, aural dictation','Year Two'),('AIM2412','Performance Skills 2 (Minor)','In this module you will be able to select one area of study from a list of performance areas, such as chamber music, directed ensembles or conducting.','Year Two'),('AHM3412','Performance Skills 3 (Minor)','Options in conducting, ensemble performance, improvisation, choral singing, piano accompaniment, singing with movement, and more','Final Year'),('AIM2105','Popular Composition and Arranging','In this module you develop your popular music composition and arranging skills by learning how to arrange for brass and strings. You will study instrumentation and stylistic techniques of arranging according to a range ','Year Two'),('AIM2408','Popular Music Directed Ensembles 1','In this module you are coached as a fully formed band in more advanced pop ensemble performance practice. The ensembles you could be in are: Folk, Blues, Funk, Reggae/ska, Prog Rock, Jazz, Laptop Ensemble, Frank Zappa Band, Guitar Orchestra, Guitar Improvisation, A Capella Choir, Samba Band plus opportunity to create originals bands. ','Year Two'),('AHM3409','Popular Music Directed Ensembles 2','Perform covers and original material in a band of your choice','Final Year'),('AHM3410','Popular Music Performance 3','This modules offers you individual tuition on a pop based instrument such as drum kit, keyboard / piano, bass, guitar and vocals. This is a continuation of Popular Music Performance 2, in which you must have obtained a pass mark of 60% to gain entry onto this module. You will learn from tutors who are leading pop performers themselves who will guide you through the various technical and musical content.','Final Year'),('AFM1404','Popular Music Performance Skills','This module introduces pop ensemble playing to you in the first year of your course. You study how to perform together in a small, acoustic group and also have a choice of more focussed tuition on either keyboard, pop singing (in a choir) or Brazilian, African and Latin percussion.','Year One'),('AIM2302','Popular Music Studies','Research the history of pop music','Year Two'),('NFE2140','Programming for Music Technology 1','Introduction to the use of  sound editing packages with video. The early part of the course will concentrate on the establishment of core skills. Simultaneously, you will begin to study and explore the creative and aesthetic aspects of adding sound and music to picture.','Final Year'),('NIE2286','Radio Production','This module will cover radio programme making, broadcasting technologies, communication theory, and the legal frameworks surrounding the production of broadcast material.','Year Two'),('NFE2173','Recording 1','Basic concepts, theory and practical use of a broad range of equipment used for recording and mixing sound. Practical experience of sound recording in a digital recording studio, in a concert hall and on location.','Year One'),('NIE2236','Recording 2','Theory and practice behind high standards of rock music production','Year Two'),('NHE2429','Recording 3','Theory and practice of recording, mixing audio, studio production and 5.1 surround sound recording and production.','Final Year'),('AHM3310','Research For Music','Explore current research in musicology and write your own research project','Final Year'),('AHM3209','Researching Music, Technology and Performance','Research is often seen as something that other people do but we are all engaged in the process of researching music all the time as we make music, perform music or listen to music. The module takes as its basis the idea that research is something that you do and researching involves a wide range of skills and abilities, not just text-based academic research.','Final Year'),('AIM2109','Scoring and Arranging for Brass Band and Symphonic Wind Orchestra','Following a week-by-week introduction to the instrumentation of the brass band and symphonic wind orchestra, techniques of writing idiomatically and resourcefully for these instruments will be investigated by means of the study and analysis of various hymn tune, piano and orchestral works. ','Year One'),('AIM2312','Scoring The Silver Screen: The Musicology Of Film And Television','Research the history of music written for television and film','Year Two'),('AIM2417','Singers And Their Songs: Music, Text And Performance Before 1600 1','Research early music, create and perform from your own editions','Year Two'),('AHM3417','Singers And Their Songs: Music, Text And Performance Before 1600 2','Research early music, create and perform from your own editions','Final Year'),('AHM1415','Solo Performance 1','Individual tuition on your instrument, leading to a solo recital, classical or pop instruments or voice','Year One'),('AIM2409','Solo Performance 1 (Major)','This module allows you to pursue solo performance and is available to all students who have received a sufficiently high mark in their solo recital in the first year. You will work closely with an individual instrumental/vocal tutor, receiving 22 hours of individual tuition, to develop your technical skills and musical insight to prepare you for a solo recital.','Year Two'),('AHM3413','Solo Performance 2 (Major)','You will work closely with an individual instrumental/vocal tutor to develop your technical skills and musical insight to prepare you for a solo recital and advanced solo performance at honours level.','Year Two'),('AIM2416','Solo Performance 2 (Minor)','Individual tuition on your instrument, leading to a solo recital, classical or pop instruments or voice','Year Two'),('AHM3416','Solo Performance 3 (Minor)','Individual tuition on your instrument, leading to a solo recital','Final Year'),('AFM1110','Songwriting 1','Compose your own songs','Year One'),('AIM2110','Songwriting 2','Compose your own songs','Year Two'),('AIM2209','Sound for Image A','You will develop a practical understanding of fundamental skills for producing sound for film, television, computer games and mobile devices. You will learn about a variety of sound production professions, and the processes of sound production within various media contexts. ','Year Two'),('AHM3403','Studies In Performance','Supporting classes for advanced solo performers, with platform time, workshops, seminars and master classes','Final Year'),('AFM1213','Stylistic Composition','Write music in a variety of different styles','Year One'),('AIM2506','Techniques Of Music Analysis 1','Explore advanced analytical techniques','Year Two'),('AHM3511','Techniques Of Music Analysis 2','Explore advanced analytical techniques','Final Year'),('AFM1208','Technology For Music','Learn to use notation software, record sound and write music using computer software','Year One'),('AFC1403','Television Production','The module introduces a range of audio and video technologies so as to provide the essential skills necessary to produce a series of short sequences and to develop the language and concepts required to evaluate the product.','Year One'),('CIT2310','The Music Industry and the Internet','This module is about the design and development of websites placed in the context of the music industry. You will develop the knowledge and practical skills needed to build interactive websites, and then undertake a music related web project where you will apply these skills.','Year Two'),('AFM1209','Theory and Analysis of Popular Music','You will explore elements of theory and analysis of popular music and develop an understanding of key theoretical principles which are important for understanding music and apply these through the analysis of a number of case studies. Over the course of the module you will study melody, harmony, rhythm and analyse a number of key works looking at structure, arrangement, and other musical ideas. Your knowledge and understanding is assessed through a theory test and a written analysis with an annotated score.','Year One'),('NHE2425','Vision and Sound','The modules aims to develop your skills in audio recording/editing and writing music for film. You will have the opportunity to record all audio and to compose original and unique music for a short film.','Final Year'),('AHM3506','Work and Professional Practice in Music','In this option, you will develop skills relevant to the world of work by studying aspects of professional practice in a number of music-related professions (for example, teaching, performing, composing, journalism, studio management, editing, recording company), followed by a suitable work placement.','Final Year');
/*!40000 ALTER TABLE `Module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `School`
--

DROP TABLE IF EXISTS `School`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `School` (
  `SchoolID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`SchoolID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `School`
--

LOCK TABLES `School` WRITE;
/*!40000 ALTER TABLE `School` DISABLE KEYS */;
INSERT INTO `School` VALUES (1,'School of Music Humanities and'),(2,'School of Computing and Engine');
/*!40000 ALTER TABLE `School` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(41) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,'saad','saad','saad@saad.com'),(2,'reba','reba','reba@reba.com');
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-28 13:39:30
